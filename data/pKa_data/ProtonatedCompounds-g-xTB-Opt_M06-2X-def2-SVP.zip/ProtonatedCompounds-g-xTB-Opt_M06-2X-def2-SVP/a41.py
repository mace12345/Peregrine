import time
start = time.time()

import json
import platform
import resource
import psi4
import basis_set_exchange as bse
import numpy as np

T = 298.15

def get_max_rss_mb():
    raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if platform.system() == 'Darwin':
        return raw / (1024 * 1024)
    return raw / 1024

psi4.set_output_file('a41.out', False)
psi4.set_memory('4000 MB')
psi4.set_num_threads(6)

metadata = {
'Identifier': 'a41',
'Charge': 1,
'Multiplicity': 1,
'CPU cores used': 6
}
with open('a41.meta.json', 'w') as f:
    json.dump(metadata, f, indent=2)

# Define psi4 molecule object
psi4MolObj = psi4.geometry('''
1 1
N 0.0686146289 -0.0841247136 0.6701338691
C 1.3964844022 -0.3886876588 0.1216231239
C 2.1024591729 -1.4144914414 0.7227531774
C 3.3541652473 -1.7393971186 0.2347231342
C 3.8841238033 -1.0417566685 -0.8388204635
C 3.1611391675 -0.0193376735 -1.4265784572
C 1.9042408108 0.3158520648 -0.9490877878
C -0.9665825579 -1.0381609733 0.2563612361
C -1.9662403115 -1.3188702471 1.1683149728
C -2.9681322742 -2.2017324732 0.8095247372
C -2.959991706 -2.7881383544 -0.4454115547
C -1.949046246 -2.4941211909 -1.3436946471
C -0.9391711084 -1.6118361628 -0.9975982781
C -0.3365385221 1.3159773425 0.5055790577
C -1.1157763862 1.7065616227 -0.5641282884
C -1.4607677666 3.0425191117 -0.6794655099
C -1.0288278809 3.9608925597 0.2621082927
C -0.2475270979 3.5481731019 1.3291123599
C 0.10462518 2.2167308923 1.4563823527
H 0.1627381275 -0.2144805076 1.6788237705
H 1.6839732268 -1.9651332025 1.5533458092
H 3.9148039837 -2.5367453735 0.6976939744
H 4.8632458894 -1.2943222356 -1.2142156015
H 3.5718247509 0.5298799672 -2.2595967664
H 1.34522887 1.120704126 -1.397555691
H -1.9771027159 -0.8524407555 2.1436868401
H -3.7523271971 -2.4309186423 1.5144681755
H -3.7411719052 -3.478577594 -0.7216503561
H -1.9372650263 -2.9535799449 -2.3199793318
H -0.1413947012 -1.3917305455 -1.6887335479
H -1.4622822221 0.9863031092 -1.287641751
H -2.0734643788 3.3598625157 -1.5092939626
H -1.3049452321 4.9991549021 0.1672103923
H 0.0879703242 4.2595399525 2.0678944456
H 0.7229176508 1.896432209 2.2837122737

units angstrom
symmetry c1
noreorient
nocom
''',
)

# Define basis sets
element_basis_map = {
    'N': 'def2-svp',
    'C': 'def2-svp',
    'H': 'def2-svp',
}
combined_basis = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in element_basis_map.items()
)
psi4.basis_helper(f'''
assign mybasis
[ mybasis ]
spherical
{combined_basis}
''', name='mybasis', key='BASIS')
metadata['Basis Set'] = element_basis_map
jkfit_basis_map = {
    'N': 'def2-universal-jkfit',
    'C': 'def2-universal-jkfit',
    'H': 'def2-universal-jkfit',
}
combined_jkfit = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in jkfit_basis_map.items()
)
psi4.basis_helper(f'''
assign myjkfit
[ myjkfit ]
spherical
{combined_jkfit}
''', name='myjkfit', key='DF_BASIS_SCF')
psi4.set_options({
    'guess': 'core',
    'scf_type': 'df',
})

# Set the shell restriction
psi4.set_options({'reference': 'rhf'})
metadata['Method'] = 'rhf m06-2x'

# Set options
psi4.set_options({'ddx': True, 'ddx_model': 'pcm', 'ddx_solvent': 'water', 'ddx_radii_set': 'uff'})

# Set up and run calculation
try:
    e_sp, wfn = psi4.energy(
        'm06-2x',
        molecule=psi4MolObj,
        return_wfn=True,
    )
except psi4.driver.p4util.exceptions.SCFConvergenceError as exc:
    metadata['Maximum RAM used (MB)'] = int(get_max_rss_mb())
    metadata['SCF error at failure'] = {
        'iteration': exc.iteration,
        'e_conv': exc.e_conv,
        'd_conv': exc.d_conv,
    }
    failed_wfn = exc.wfn  # partial wavefunction at the point of failure
    coords_bohr = np.array(failed_wfn.molecule().geometry())
    metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
    with open('a41.meta.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    exit()
# Save properties
coords_bohr = np.array(wfn.molecule().geometry())
grad = np.array(wfn.gradient())
basis = wfn.basisset()
metadata['Electronic Energy (Eh)'] = psi4.variable('CURRENT ENERGY')
metadata['One Electron Energy (Eh)'] = psi4.variable('ONE-ELECTRON ENERGY')
metadata['Two Electron Energy (Eh)'] = psi4.variable('TWO-ELECTRON ENERGY')
metadata['Nuclear Repulsion Energy (Eh)'] = psi4.variable('NUCLEAR REPULSION ENERGY')
metadata['Gradient (Eh/Bohr)'] = grad.tolist()
metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
metadata['Number of Primitive Basis Functions'] = basis.nprimitive()
# Calculate and save more properties
psi4.oeprop(
    wfn,
    'DIPOLE',
    'QUADRUPOLE',
    'MULLIKEN_CHARGES',
    'LOWDIN_CHARGES',
    'WIBERG_LOWDIN_INDICES',
    'MAYER_INDICES',
)
metadata['Dipole'] = np.array(wfn.variable('CURRENT DIPOLE')).tolist()
metadata['Quadrupole'] = np.array(wfn.variable('QUADRUPOLE')).tolist()
metadata['Mulliken Charges'] = np.array(wfn.variable('MULLIKEN CHARGES')).tolist()
metadata['Lowdin Charges'] = np.array(wfn.variable('LOWDIN CHARGES')).tolist()
metadata['Wiberg Bond Orders'] = np.array(wfn.array_variable('WIBERG LOWDIN INDICES')).tolist()
metadata['Mayer Bond Orders']  = np.array(wfn.array_variable('MAYER INDICES')).tolist()
# Save Fock matricies
F_ao = np.array(wfn.Fa_subset('AO'))
metadata['Fock Matrix File Name'] = 'a41.fock'
np.savetxt('a41.fock', F_ao, fmt='%.16e')
# Get HOMO and LUMO energies
homo_idx = wfn.nalpha() - 1
lumo_idx = wfn.nalpha()
eps_a = wfn.epsilon_a_subset("AO", "ALL").np
metadata['HOMO Energy (Eh)'] = float(eps_a[homo_idx])
metadata['LUMO Energy (Eh)'] = float(eps_a[lumo_idx])

RAM = int(get_max_rss_mb())
end = time.time()
time_taken = int(round(end - start, 0))
metadata['Time Taken (s)'] = time_taken
metadata['Maximum RAM used (MB)'] = RAM
with open('a41.meta.json', 'w') as f:
   json.dump(metadata, f, indent=2)
