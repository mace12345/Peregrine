import time
start = time.time()

import json
import platform
import resource
import psi4
import basis_set_exchange as bse
import numpy as np

T = 298.15

def get_max_rss_mb():
    raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if platform.system() == 'Darwin':
        return raw / (1024 * 1024)
    return raw / 1024

psi4.set_output_file('a26.out', False)
psi4.set_memory('4000 MB')
psi4.set_num_threads(6)

metadata = {
'Identifier': 'a26',
'Charge': 0,
'Multiplicity': 1,
'CPU cores used': 6
}
with open('a26.meta.json', 'w') as f:
    json.dump(metadata, f, indent=2)

# Define psi4 molecule object
psi4MolObj = psi4.geometry('''
0 1
C -2.4524461633 0.7025903376 1.0217724719
C -1.801608581 -0.0264319524 0.1278412296
O -2.496376433 -0.8654737254 -0.6969903346
C -0.3334584994 -0.0348282932 -0.0193730392
C 0.3301474512 -1.202341971 -0.3845721525
C 1.7077123704 -1.2188437781 -0.5107522831
C 2.4414735655 -0.0680132019 -0.2804572851
C 1.7898531426 1.099479498 0.0811673815
C 0.4130125179 1.1157133201 0.2101852393
H -3.5267332731 0.6566122745 1.0858641883
H -1.9195824621 1.333050224 1.7148314343
H -1.8980375278 -1.1936402095 -1.3724451095
H -0.2319631406 -2.1117506694 -0.5432770771
H 2.2087806429 -2.1360569231 -0.7852451005
H 3.5165882971 -0.0804564771 -0.3838802182
H 2.3548593913 2.0037044588 0.2561068067
H -0.1022212985 2.0266870882 0.4792238483

units angstrom
symmetry c1
noreorient
nocom
''',
)

# Define basis sets
element_basis_map = {
    'C': 'def2-svp',
    'O': 'def2-svp',
    'H': 'def2-svp',
}
combined_basis = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in element_basis_map.items()
)
psi4.basis_helper(f'''
assign mybasis
[ mybasis ]
spherical
{combined_basis}
''', name='mybasis', key='BASIS')
metadata['Basis Set'] = element_basis_map
jkfit_basis_map = {
    'C': 'def2-universal-jkfit',
    'O': 'def2-universal-jkfit',
    'H': 'def2-universal-jkfit',
}
combined_jkfit = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in jkfit_basis_map.items()
)
psi4.basis_helper(f'''
assign myjkfit
[ myjkfit ]
spherical
{combined_jkfit}
''', name='myjkfit', key='DF_BASIS_SCF')
psi4.set_options({
    'guess': 'core',
    'scf_type': 'df',
})

# Set the shell restriction
psi4.set_options({'reference': 'rhf'})
metadata['Method'] = 'rhf m06-2x'

# Set options
psi4.set_options({'ddx': True, 'ddx_model': 'pcm', 'ddx_solvent': 'water', 'ddx_radii_set': 'uff'})

# Set up and run calculation
try:
    e_sp, wfn = psi4.energy(
        'm06-2x',
        molecule=psi4MolObj,
        return_wfn=True,
    )
except psi4.driver.p4util.exceptions.SCFConvergenceError as exc:
    metadata['Maximum RAM used (MB)'] = int(get_max_rss_mb())
    metadata['SCF error at failure'] = {
        'iteration': exc.iteration,
        'e_conv': exc.e_conv,
        'd_conv': exc.d_conv,
    }
    failed_wfn = exc.wfn  # partial wavefunction at the point of failure
    coords_bohr = np.array(failed_wfn.molecule().geometry())
    metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
    with open('a26.meta.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    exit()
# Save properties
coords_bohr = np.array(wfn.molecule().geometry())
grad = np.array(wfn.gradient())
basis = wfn.basisset()
metadata['Electronic Energy (Eh)'] = psi4.variable('CURRENT ENERGY')
metadata['One Electron Energy (Eh)'] = psi4.variable('ONE-ELECTRON ENERGY')
metadata['Two Electron Energy (Eh)'] = psi4.variable('TWO-ELECTRON ENERGY')
metadata['Nuclear Repulsion Energy (Eh)'] = psi4.variable('NUCLEAR REPULSION ENERGY')
metadata['Gradient (Eh/Bohr)'] = grad.tolist()
metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
metadata['Number of Primitive Basis Functions'] = basis.nprimitive()
# Calculate and save more properties
psi4.oeprop(
    wfn,
    'DIPOLE',
    'QUADRUPOLE',
    'MULLIKEN_CHARGES',
    'LOWDIN_CHARGES',
    'WIBERG_LOWDIN_INDICES',
    'MAYER_INDICES',
)
metadata['Dipole'] = np.array(wfn.variable('CURRENT DIPOLE')).tolist()
metadata['Quadrupole'] = np.array(wfn.variable('QUADRUPOLE')).tolist()
metadata['Mulliken Charges'] = np.array(wfn.variable('MULLIKEN CHARGES')).tolist()
metadata['Lowdin Charges'] = np.array(wfn.variable('LOWDIN CHARGES')).tolist()
metadata['Wiberg Bond Orders'] = np.array(wfn.array_variable('WIBERG LOWDIN INDICES')).tolist()
metadata['Mayer Bond Orders']  = np.array(wfn.array_variable('MAYER INDICES')).tolist()
# Save Fock matricies
F_ao = np.array(wfn.Fa_subset('AO'))
metadata['Fock Matrix File Name'] = 'a26.fock'
np.savetxt('a26.fock', F_ao, fmt='%.16e')
# Get HOMO and LUMO energies
homo_idx = wfn.nalpha() - 1
lumo_idx = wfn.nalpha()
eps_a = wfn.epsilon_a_subset("AO", "ALL").np
metadata['HOMO Energy (Eh)'] = float(eps_a[homo_idx])
metadata['LUMO Energy (Eh)'] = float(eps_a[lumo_idx])

RAM = int(get_max_rss_mb())
end = time.time()
time_taken = int(round(end - start, 0))
metadata['Time Taken (s)'] = time_taken
metadata['Maximum RAM used (MB)'] = RAM
with open('a26.meta.json', 'w') as f:
   json.dump(metadata, f, indent=2)
