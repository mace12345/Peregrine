import time
start = time.time()

import json
import platform
import resource
import psi4
import basis_set_exchange as bse
import numpy as np

T = 298.15

def get_max_rss_mb():
    raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if platform.system() == 'Darwin':
        return raw / (1024 * 1024)
    return raw / 1024

psi4.set_output_file('a65.out', False)
psi4.set_memory('4000 MB')
psi4.set_num_threads(6)

metadata = {
'Identifier': 'a65',
'Charge': 0,
'Multiplicity': 1,
'CPU cores used': 6
}
with open('a65.meta.json', 'w') as f:
    json.dump(metadata, f, indent=2)

# Define psi4 molecule object
psi4MolObj = psi4.geometry('''
0 1
N 0.1817045641 -0.3618706776 0.8361165428
Si -1.4492588987 0.0896906198 0.5510542035
C -1.7065084346 1.9386181345 0.7026740028
C -1.9732806123 -0.4357775687 -1.1674011996
C -2.5158342189 -0.7694781362 1.8276844608
Si 1.5186913582 -0.2281153851 -0.2315829515
C 3.0841099715 -0.3631328468 0.7866878102
C 1.4784532706 1.4232887921 -1.111944428
C 1.5272614912 -1.5826648798 -1.5249359378
H 0.3763033418 -0.7497248749 1.7315938338
H -1.1075528836 2.4860334636 -0.0224868912
H -2.7513779236 2.2012337708 0.5318696838
H -1.436018749 2.3032251232 1.6936710937
H -1.8878179366 -1.5140622721 -1.3000180273
H -1.3662599471 0.0411506804 -1.9364658749
H -3.0121031439 -0.1609897944 -1.3550923619
H -2.2421161698 -0.4722075812 2.8402390012
H -2.4246132714 -1.8533563589 1.7639601684
H -3.5684432437 -0.5205355627 1.6905721099
H 3.1423099258 0.4217609961 1.5401495479
H 3.1425134263 -1.3224027151 1.3013912971
H 3.9701348463 -0.2792065622 0.1568664425
H 1.5173532822 2.2537513158 -0.4073447254
H 2.3300519248 1.5221447058 -1.7864525774
H 0.574630457 1.5386561268 -1.7095513604
H 1.5691472485 -2.5727843176 -1.070985173
H 2.3926406308 -1.4877444296 -2.1822151954
H 0.6358796941 -1.545499766 -2.1480534946

units angstrom
symmetry c1
noreorient
nocom
''',
)

# Define basis sets
element_basis_map = {
    'N': 'def2-svp',
    'C': 'def2-svp',
    'H': 'def2-svp',
    'Si': 'def2-svp',
}
combined_basis = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in element_basis_map.items()
)
psi4.basis_helper(f'''
assign mybasis
[ mybasis ]
spherical
{combined_basis}
''', name='mybasis', key='BASIS')
metadata['Basis Set'] = element_basis_map
jkfit_basis_map = {
    'N': 'def2-universal-jkfit',
    'C': 'def2-universal-jkfit',
    'H': 'def2-universal-jkfit',
    'Si': 'def2-universal-jkfit',
}
combined_jkfit = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in jkfit_basis_map.items()
)
psi4.basis_helper(f'''
assign myjkfit
[ myjkfit ]
spherical
{combined_jkfit}
''', name='myjkfit', key='DF_BASIS_SCF')
psi4.set_options({
    'guess': 'core',
    'scf_type': 'df',
})

# Set the shell restriction
psi4.set_options({'reference': 'rhf'})
metadata['Method'] = 'rhf m06-2x'

# Set options
psi4.set_options({'ddx': True, 'ddx_model': 'pcm', 'ddx_solvent': 'water', 'ddx_radii_set': 'uff'})

# Set up and run calculation
try:
    e_sp, wfn = psi4.energy(
        'm06-2x',
        molecule=psi4MolObj,
        return_wfn=True,
    )
except psi4.driver.p4util.exceptions.SCFConvergenceError as exc:
    metadata['Maximum RAM used (MB)'] = int(get_max_rss_mb())
    metadata['SCF error at failure'] = {
        'iteration': exc.iteration,
        'e_conv': exc.e_conv,
        'd_conv': exc.d_conv,
    }
    failed_wfn = exc.wfn  # partial wavefunction at the point of failure
    coords_bohr = np.array(failed_wfn.molecule().geometry())
    metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
    with open('a65.meta.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    exit()
# Save properties
coords_bohr = np.array(wfn.molecule().geometry())
grad = np.array(wfn.gradient())
basis = wfn.basisset()
metadata['Electronic Energy (Eh)'] = psi4.variable('CURRENT ENERGY')
metadata['One Electron Energy (Eh)'] = psi4.variable('ONE-ELECTRON ENERGY')
metadata['Two Electron Energy (Eh)'] = psi4.variable('TWO-ELECTRON ENERGY')
metadata['Nuclear Repulsion Energy (Eh)'] = psi4.variable('NUCLEAR REPULSION ENERGY')
metadata['Gradient (Eh/Bohr)'] = grad.tolist()
metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
metadata['Number of Primitive Basis Functions'] = basis.nprimitive()
# Calculate and save more properties
psi4.oeprop(
    wfn,
    'DIPOLE',
    'QUADRUPOLE',
    'MULLIKEN_CHARGES',
    'LOWDIN_CHARGES',
    'WIBERG_LOWDIN_INDICES',
    'MAYER_INDICES',
)
metadata['Dipole'] = np.array(wfn.variable('CURRENT DIPOLE')).tolist()
metadata['Quadrupole'] = np.array(wfn.variable('QUADRUPOLE')).tolist()
metadata['Mulliken Charges'] = np.array(wfn.variable('MULLIKEN CHARGES')).tolist()
metadata['Lowdin Charges'] = np.array(wfn.variable('LOWDIN CHARGES')).tolist()
metadata['Wiberg Bond Orders'] = np.array(wfn.array_variable('WIBERG LOWDIN INDICES')).tolist()
metadata['Mayer Bond Orders']  = np.array(wfn.array_variable('MAYER INDICES')).tolist()
# Save Fock matricies
F_ao = np.array(wfn.Fa_subset('AO'))
metadata['Fock Matrix File Name'] = 'a65.fock'
np.savetxt('a65.fock', F_ao, fmt='%.16e')
# Get HOMO and LUMO energies
homo_idx = wfn.nalpha() - 1
lumo_idx = wfn.nalpha()
eps_a = wfn.epsilon_a_subset("AO", "ALL").np
metadata['HOMO Energy (Eh)'] = float(eps_a[homo_idx])
metadata['LUMO Energy (Eh)'] = float(eps_a[lumo_idx])

RAM = int(get_max_rss_mb())
end = time.time()
time_taken = int(round(end - start, 0))
metadata['Time Taken (s)'] = time_taken
metadata['Maximum RAM used (MB)'] = RAM
with open('a65.meta.json', 'w') as f:
   json.dump(metadata, f, indent=2)
