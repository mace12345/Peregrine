import time
start = time.time()

import json
import platform
import resource
import psi4
import basis_set_exchange as bse
import numpy as np

T = 298.15

def get_max_rss_mb():
    raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if platform.system() == 'Darwin':
        return raw / (1024 * 1024)
    return raw / 1024

psi4.set_output_file('a14.out', False)
psi4.set_memory('4000 MB')
psi4.set_num_threads(6)

metadata = {
'Identifier': 'a14',
'Charge': 0,
'Multiplicity': 1,
'CPU cores used': 6
}
with open('a14.meta.json', 'w') as f:
    json.dump(metadata, f, indent=2)

# Define psi4 molecule object
psi4MolObj = psi4.geometry('''
0 1
P -0.2031915038 0.0001153788 -0.6383873022
N -0.9461794795 1.2011894872 0.2449003413
C -2.402356034 1.1326663573 0.2206070118
C -0.4466348242 2.5462114971 -0.0027514485
N 1.4060141646 0.2294416588 -0.3830531064
C 2.3386702334 0.1860964046 -1.4873977535
C 1.9754298243 0.287820501 0.9416957269
N -0.7189998836 -1.3833754904 0.1025469041
C -0.7345728813 -1.5379599148 1.5390288798
C -0.6061923671 -2.6108795167 -0.6598955883
O -0.5050376355 -0.016024221 -2.0645648464
H -2.7127459532 0.1085328225 0.4112059109
H -2.8132155157 1.7876736816 0.9923971263
H -2.7985349025 1.439427705 -0.7529143297
H 0.6362970668 2.5528414695 0.0924955706
H -0.8754785075 3.2322994059 0.7310449202
H -0.7111847107 2.8949418635 -1.0073583673
H 2.9802435024 -0.7028419102 -1.4367393128
H 2.9859599226 1.0711545163 -1.4849447412
H 1.7639060448 0.1607875915 -2.4082025725
H 1.1901636935 0.5179642296 1.6601693566
H 2.7381151643 1.0735588581 0.992946387
H 2.4532734321 -0.6587456377 1.2266002605
H -0.8998972956 -0.5651462705 1.9980611046
H -1.5490081713 -2.2090935259 1.8309870536
H 0.2025089552 -1.9606813655 1.9223510519
H -1.3907083035 -3.3114085062 -0.3589603781
H 0.3658650644 -3.1006170894 -0.5099314306
H -0.7225090993 -2.3659499801 -1.7119364288

units angstrom
symmetry c1
noreorient
nocom
''',
)

# Define basis sets
element_basis_map = {
    'P': 'def2-svp',
    'N': 'def2-svp',
    'O': 'def2-svp',
    'H': 'def2-svp',
    'C': 'def2-svp',
}
combined_basis = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in element_basis_map.items()
)
psi4.basis_helper(f'''
assign mybasis
[ mybasis ]
spherical
{combined_basis}
''', name='mybasis', key='BASIS')
metadata['Basis Set'] = element_basis_map
jkfit_basis_map = {
    'P': 'def2-universal-jkfit',
    'N': 'def2-universal-jkfit',
    'O': 'def2-universal-jkfit',
    'H': 'def2-universal-jkfit',
    'C': 'def2-universal-jkfit',
}
combined_jkfit = '\n'.join(
    bse.get_basis(basisname, elements=[symbol], fmt='psi4', header=False)
    for symbol, basisname in jkfit_basis_map.items()
)
psi4.basis_helper(f'''
assign myjkfit
[ myjkfit ]
spherical
{combined_jkfit}
''', name='myjkfit', key='DF_BASIS_SCF')
psi4.set_options({
    'guess': 'core',
    'scf_type': 'df',
})

# Set the shell restriction
psi4.set_options({'reference': 'rhf'})
metadata['Method'] = 'rhf m06-2x'

# Set options
psi4.set_options({'ddx': True, 'ddx_model': 'pcm', 'ddx_solvent': 'water', 'ddx_radii_set': 'uff'})

# Set up and run calculation
try:
    e_sp, wfn = psi4.energy(
        'm06-2x',
        molecule=psi4MolObj,
        return_wfn=True,
    )
except psi4.driver.p4util.exceptions.SCFConvergenceError as exc:
    metadata['Maximum RAM used (MB)'] = int(get_max_rss_mb())
    metadata['SCF error at failure'] = {
        'iteration': exc.iteration,
        'e_conv': exc.e_conv,
        'd_conv': exc.d_conv,
    }
    failed_wfn = exc.wfn  # partial wavefunction at the point of failure
    coords_bohr = np.array(failed_wfn.molecule().geometry())
    metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
    with open('a14.meta.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    exit()
# Save properties
coords_bohr = np.array(wfn.molecule().geometry())
grad = np.array(wfn.gradient())
basis = wfn.basisset()
metadata['Electronic Energy (Eh)'] = psi4.variable('CURRENT ENERGY')
metadata['One Electron Energy (Eh)'] = psi4.variable('ONE-ELECTRON ENERGY')
metadata['Two Electron Energy (Eh)'] = psi4.variable('TWO-ELECTRON ENERGY')
metadata['Nuclear Repulsion Energy (Eh)'] = psi4.variable('NUCLEAR REPULSION ENERGY')
metadata['Gradient (Eh/Bohr)'] = grad.tolist()
metadata['Coordinates (Bohr)'] = coords_bohr.tolist()
metadata['Number of Primitive Basis Functions'] = basis.nprimitive()
# Calculate and save more properties
psi4.oeprop(
    wfn,
    'DIPOLE',
    'QUADRUPOLE',
    'MULLIKEN_CHARGES',
    'LOWDIN_CHARGES',
    'WIBERG_LOWDIN_INDICES',
    'MAYER_INDICES',
)
metadata['Dipole'] = np.array(wfn.variable('CURRENT DIPOLE')).tolist()
metadata['Quadrupole'] = np.array(wfn.variable('QUADRUPOLE')).tolist()
metadata['Mulliken Charges'] = np.array(wfn.variable('MULLIKEN CHARGES')).tolist()
metadata['Lowdin Charges'] = np.array(wfn.variable('LOWDIN CHARGES')).tolist()
metadata['Wiberg Bond Orders'] = np.array(wfn.array_variable('WIBERG LOWDIN INDICES')).tolist()
metadata['Mayer Bond Orders']  = np.array(wfn.array_variable('MAYER INDICES')).tolist()
# Save Fock matricies
F_ao = np.array(wfn.Fa_subset('AO'))
metadata['Fock Matrix File Name'] = 'a14.fock'
np.savetxt('a14.fock', F_ao, fmt='%.16e')
# Get HOMO and LUMO energies
homo_idx = wfn.nalpha() - 1
lumo_idx = wfn.nalpha()
eps_a = wfn.epsilon_a_subset("AO", "ALL").np
metadata['HOMO Energy (Eh)'] = float(eps_a[homo_idx])
metadata['LUMO Energy (Eh)'] = float(eps_a[lumo_idx])

RAM = int(get_max_rss_mb())
end = time.time()
time_taken = int(round(end - start, 0))
metadata['Time Taken (s)'] = time_taken
metadata['Maximum RAM used (MB)'] = RAM
with open('a14.meta.json', 'w') as f:
   json.dump(metadata, f, indent=2)
